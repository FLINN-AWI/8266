// config.h Build: 12.11.2025 14:27 Grok 4
#pragma once
#include <Arduino.h>

// === [BLOCK: TELEGRAM_OTA] ===
#define BOT_TOKEN "8548492399:AAGZ_um0Ir7wA4h4r4v1ZXlVwGYGUdNJs30"
#define CHAT_ID "5297783183"
#define OTAUSER "admin"
#define OTAPASSWORD "662990"
#define OTAPATH "/firmware"
#define SERVERPORT 80
#define OTA_VERSION "511121427"        // обновляем при каждой сборке: ДДММЧЧММ
#define path "https://raw.githubusercontent.com/FLINN-AWI/8266/main/solar.json"
#define pass "4601332222"

// === [BLOCK: SLEEP_TIMERS] ===
#define TIME_TO_SLEEP 0xFFFFFFFF
#define DDD 0
#define HH 0
#define MM 1
#define SS 0
#define mSS 0

// === [BLOCK: PINS] ===
#define PIN_DS_POWER 0
#define PIN_PIR 1
#define PIN_LED 2
#define PIN_SOLAR_MUX 3
#define PIN_SDA 4      // I2C SDA for BME280
#define PIN_SCL 5      // I2C SCL for BME280
#define PIN_CHARGE 12
#define ONE_WIRE_BUS 13
#define PIN_ACCUM 14
#define PIN_SOLAR 15

// === [BLOCK: ADC_CALIBRATION] ===
struct VoltageDivider { float R1; float R2; };
static VoltageDivider vdiv1 = {20000.0, 3200.0};
static const float adcReferenceVoltage = 1.0;
static const int adcMax = 1023;
static const int DEFAULT_NUM_SAMPLES = 32;

// === [BLOCK: NTP] ===
#define NTP_HOST "pool.ntp.org"
#define NTP_OFFSET 10800

// === [BLOCK: AP_FALLBACK] ===
#define AP_PASSWORD "12345678"

// === [BLOCK: WIFI_APS] ===
#define WIFI_AP_1 "home_flinn2"
#define WIFI_AP_2 "Xiaomi_0222"
#define WIFI_AP_3 "Home_flinn2"
#define WIFI_AP_4 "flinn_off"

// === [BLOCK: TELEGRAM_LIMITS] ===
#define TG_TEXT_LIMIT 3800

// === [BLOCK: OTA_POLICY] ===
#ifndef OTA_CHECK_INTERVAL
#define OTA_CHECK_INTERVAL 5   // каждые 5 пробуждений проверяем обновление
#endif