// main.cpp Build: 12.11.2025 14:27 Grok 4
#include <Arduino.h>
#include <EEPROM.h>
#include <ArduinoJson.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPUpdateServer.h>
#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <NTPClient.h>
#include <WiFiUdp.h>
#include <ESP8266WiFiMulti.h>
#include <EspSleep.h>
#include <AutoOTA.h>
#include <FastBot2.h>
#include <Adafruit_BME280.h>
#include "config.h"

// Wake counter (EEPROM) for OTA interval
static const uint32_t WAKE_EE_MAGIC = 0xA55A5AA5;
struct WakeStore { uint32_t magic; uint32_t counter; };

static uint32_t loadWakeCounter() {
  WakeStore st{};
  EEPROM.begin(sizeof(WakeStore));
  EEPROM.get(0, st);
  if (st.magic != WAKE_EE_MAGIC) {
    st.magic = WAKE_EE_MAGIC;
    st.counter = 0;
    EEPROM.put(0, st);
    EEPROM.commit();
  }
  EEPROM.end();
  return st.counter;
}

static void saveWakeCounter(uint32_t val) {
  WakeStore st{WAKE_EE_MAGIC, val};
  EEPROM.begin(sizeof(WakeStore));
  EEPROM.put(0, st);
  EEPROM.commit();
  EEPROM.end();
}

enum VoltageType { ACC, SOLAR, CHARGE };

float measureVoltage(uint8_t analogPin, VoltageDivider divider, VoltageType type, int samples = DEFAULT_NUM_SAMPLES) {
  long sum = 0;
  for (int i = 0; i < samples; i++) {
    sum += analogRead(analogPin);
    delay(2);
  }
  float avgRaw = sum / (float)samples;
  float voltageA0 = (avgRaw / adcMax) * adcReferenceVoltage;
  float inputVoltage = voltageA0 * (divider.R1 + divider.R2) / divider.R2;
  
  // EMA фильтр (alpha = 0.1)
  static float lastValues[3] = {-1.0f, -1.0f, -1.0f};
  const float alpha = 0.1f;
  
  float filtered = inputVoltage;
  int idx = (int)type;
  if (lastValues[idx] >= 0) {
    filtered = alpha * inputVoltage + (1 - alpha) * lastValues[idx];
  }
  lastValues[idx] = filtered;
  
  return filtered;
}

// Globals
AutoOTA ota(OTA_VERSION, path);
ESP8266WiFiMulti wifiMulti;
FastBot2 bot;
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, NTP_HOST);
ESP8266WebServer HttpServer(SERVERPORT);
ESP8266HTTPUpdateServer httpUpdater;
EspSleep sleep;

// BME280
Adafruit_BME280 bme;

String twoDigits(int number) {
  if (number < 10) return "0" + String(number);
  return String(number);
}

void setup() {
  sleep.tick();

  Serial.begin(115200);
  Serial.println();
  Serial.print("Version ");
  Serial.println(ota.version());

  Wire.begin(PIN_SDA, PIN_SCL);

  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, 0);
  pinMode(PIN_DS_POWER, OUTPUT);
  digitalWrite(PIN_DS_POWER, HIGH);
  pinMode(PIN_SOLAR, OUTPUT);
  digitalWrite(PIN_SOLAR, HIGH);
  pinMode(PIN_CHARGE, OUTPUT);
  digitalWrite(PIN_CHARGE, HIGH);
  pinMode(PIN_ACCUM, OUTPUT);
  digitalWrite(PIN_ACCUM, HIGH);
  pinMode(PIN_SOLAR_MUX, OUTPUT);
  digitalWrite(PIN_SOLAR_MUX, LOW);

  String PIR = String(digitalRead(PIN_PIR));
  WiFi.persistent(false);

  digitalWrite(PIN_ACCUM, LOW);
  delay(100);
  float Acc = measureVoltage(A0, vdiv1, ACC);
  digitalWrite(PIN_ACCUM, HIGH);

  digitalWrite(PIN_SOLAR_MUX, LOW);
  delay(100);
  float Solar = measureVoltage(A0, vdiv1, SOLAR);
  digitalWrite(PIN_SOLAR_MUX, HIGH);

  digitalWrite(PIN_CHARGE, LOW);
  delay(100);
  float Charge = measureVoltage(A0, vdiv1, CHARGE);
  digitalWrite(PIN_CHARGE, HIGH);

  OneWire oneWire(ONE_WIRE_BUS);
  DallasTemperature sensors(&oneWire);
  sensors.begin();
  sensors.requestTemperatures();
  float t_ds = sensors.getTempCByIndex(0);

  if (!bme.begin(0x76)) {
    Serial.println("BME280 не найден! Пробуем 0x77...");
    if (!bme.begin(0x77)) Serial.println("BME280 всё равно не найден!");
  }
  float t_bme = bme.readTemperature();
  float h = bme.readHumidity();
  float p = bme.readPressure() / 100.0F;

  WiFi.mode(WIFI_STA);
  Serial.println("scan start");
  int n = WiFi.scanNetworks();
  Serial.println("scan done");

  String wifiList = "[";
  if (n == 0) {
    wifiList += "no networks";
  } else {
    struct Net { String s; long r; };
    Net* arr = new Net[n];
    for (int i = 0; i < n; i++) {
      arr[i].s = WiFi.SSID(i);
      arr[i].r = WiFi.RSSI(i);
    }
    for (int i = 0; i < n; i++) {
      int best = i;
      for (int j = i + 1; j < n; j++)
        if (arr[j].r > arr[best].r) best = j;
      if (best != i) {
        Net tmp = arr[i]; arr[i] = arr[best]; arr[best] = tmp;
      }
    }
    for (int i = 0; i < n; i++) {
      wifiList += arr[i].s + ":" + String(arr[i].r) + "dBm";
      if (i < n - 1) wifiList += ", ";
    }
    delete[] arr;
  }
  wifiList += "]";

  wifiMulti.addAP(WIFI_AP_1, pass);
  wifiMulti.addAP(WIFI_AP_2, pass);
  wifiMulti.addAP(WIFI_AP_3, pass);
  wifiMulti.addAP(WIFI_AP_4, pass);

  const uint32_t connectTimeoutMs = 5000;
  bool isConnected = (wifiMulti.run(connectTimeoutMs) == WL_CONNECTED);
  String IP, SSID = "", RSSI_str = "", ssid = "", HOME = "";

  if (isConnected) {
    Serial.println("WiFi connected to: " + WiFi.SSID());
    SSID = WiFi.SSID();
    RSSI_str = String(WiFi.RSSI());
    ssid = SSID;
    HOME = RSSI_str;
    IP = WiFi.localIP().toString();

    httpUpdater.setup(&HttpServer, OTAPATH, OTAUSER, OTAPASSWORD);
    HttpServer.begin();
    Serial.println("HTTP OTA server started via Wi-Fi");
  } else {
    Serial.println("WiFi connection FAILED! Starting AP...");
    WiFi.mode(WIFI_AP);
    String apName = "ESP8266_OTA_" + String(ESP.getChipId(), HEX);
    WiFi.softAP(apName.c_str(), AP_PASSWORD);
    IP = WiFi.softAPIP().toString();

    pinMode(LED_BUILTIN, OUTPUT);
    digitalWrite(LED_BUILTIN, HIGH);

    HttpServer.on("/", [apName, t_bme, Acc, IP]() {
      String html = "<!DOCTYPE html><html><head><meta charset='utf-8'>"
                    "<title>ESP8266 OTA</title><style>body{font-family:Arial;text-align:center;background:#0a0a0a;color:#eee;}"
                    ".container{margin-top:40px;}button{padding:10px 25px;font-size:18px;border:none;border-radius:10px;background:#007bff;color:#fff;}"
                    "button:hover{background:#0056b3;}</style></head><body><div class='container'>"
                    "<h2>ESP8266 OTA Update Mode</h2><p><strong>SSID:</strong> " + WiFi.softAPSSID() + "</p>"
                    "<p><strong>IP:</strong> " + WiFi.softAPIP().toString() + "</p>"
                    "<p><strong>Version:</strong> " + String(ota.version()) + "</p>"
                    "<p><strong>T BME280:</strong> " + String(t_bme,1) + " °C</p>"
                    "<p><strong>Battery:</strong> " + String(Acc,2) + " V</p>"
                    "<br><a href='/update'><button>Обновить прошивку</button></a></div></body></html>";
      HttpServer.send(200, "text/html", html);
    });

    httpUpdater.setup(&HttpServer);
    HttpServer.begin();

    unsigned long prevMillis = 0, apStartTime = millis();
    bool ledState = false;
    while (millis() - apStartTime < 120000) {
      HttpServer.handleClient();
      if (millis() - prevMillis >= 100) {
        prevMillis = millis();
        ledState = !ledState;
        digitalWrite(LED_BUILTIN, ledState ? LOW : HIGH);
      }
      delay(10);
    }
    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_OFF);
    ssid = "AP"; HOME = "0";
  }

  configTime(0, 0, NTP_HOST);
  timeClient.begin();
  timeClient.setTimeOffset(NTP_OFFSET);
  timeClient.update();
  String Time = timeClient.getFormattedTime();
  time_t epochTime = timeClient.getEpochTime();
  struct tm* ptm = gmtime(&epochTime);
  String Date = String(ptm->tm_mday) + "/" + String(ptm->tm_mon + 1) + "/" + String(ptm->tm_year + 1900);

  uint32_t MEM0 = ESP.getFreeHeap();
  uint32_t MEM = ESP.getFreeHeap();
  String MAC = WiFi.macAddress();

  String txt = "ver." + String(ota.version()) +
    ", SLEEP=" + String(DDD) + "d " + twoDigits(HH) + ":" + twoDigits(MM) +
    ", FreeMEM " + String(MEM0 - MEM) +
    ", PIR=" + PIR +
    ", " + Time + ", " + Date +
    " T_DS=" + String(t_ds) + 
    ", T_BME=" + String(t_bme,1) + 
    ", H=" + String(h,1) + 
    ", P=" + String(p,1) + 
    ", Icharge " + String((Charge - Acc) / 0.11 * 1000, 0) +
    "mA, Acc=" + String(Acc,3) +
    ", Charge=" + String(Charge,3) +
    ", Solar=" + String(Solar,3) + " " +
    SSID + "=" + RSSI_str + "dBm, HOME=" + ssid + HOME + "dBm, " + IP + ", " + MAC +
    " " + String(path) + ", WiFi=" + wifiList +
    ", Uptime=" + String(millis()/1000.0,1) + "s";

  bot.setToken(BOT_TOKEN);
  bot.setPollMode(fb::Poll::Long, 20000);

  uint32_t currentCounter = loadWakeCounter();
  uint32_t nextWake = currentCounter + 1;
  bool doOtaCheck = (nextWake >= OTA_CHECK_INTERVAL);
  int remaining = OTA_CHECK_INTERVAL - nextWake;
  if (remaining > 0) txt += ", до автообновления осталось " + String(remaining);
  if (doOtaCheck) {
    txt += ", Проверка автообновления...";
    saveWakeCounter(0);
  } else {
    saveWakeCounter(nextWake);
  }

  bot.sendMessage(fb::Message(txt, CHAT_ID));
  bot.tick();
  digitalWrite(PIN_LED, 0);

  if (doOtaCheck) {
    String ver, notes;
    if (ota.checkUpdate(&ver, &notes)) {
      Serial.println(ver); Serial.println(notes);
      ota.update();
    }
  }
}

void loop() {
  if (ota.tick()) Serial.println((int)ota.getError());
  HttpServer.handleClient();
  bot.tick();
  static uint32_t tmr1 = 0;
  if (millis() - tmr1 >= 100) {
    tmr1 = millis();
    Serial.println("TO_SLEEP");
    sleep.sleep(mSS, SS, MM, HH, DDD);
  }
}